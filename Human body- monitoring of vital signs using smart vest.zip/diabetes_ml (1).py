#!/usr/bin/env python
# coding: utf-8

# In[53]:


import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


# In[54]:


diabetes_frame=pd.read_csv("C:\\Users\\Rohith\\Downloads\\pima-indians-diabetes-database\\diabetes.csv")


# In[55]:


diabetes_frame.head(5)


# In[56]:


diabetes_frame['Pregnancies'].value_counts()


# In[57]:


diabetes_frame['Pregnancies'].value_counts() #....no missing values found......


# In[58]:


diabetes_frame['Outcome'].value_counts()


# In[59]:


diabetes_frame[['Glucose','BloodPressure','SkinThickness','Insulin','BMI']] = diabetes_frame[['Glucose','BloodPressure','SkinThickness','Insulin','BMI']].replace(0,np.NaN)


# In[60]:


diabetes_frame.info()


# In[61]:


correlation_matrix=diabetes_frame.corr()
correlation_matrix


# In[62]:


sns.heatmap(correlation_matrix, annot=True)


# In[63]:


diabetes_frame.head()


# In[64]:


diabetes_frame.info()


# In[65]:


diabetes_frame['Insulin']=diabetes_frame['Insulin'].fillna(diabetes_frame['Insulin'].mean())


# In[66]:


diabetes_frame['BloodPressure']=diabetes_frame['BloodPressure'].fillna(diabetes_frame['BloodPressure'].mean())


# In[67]:


diabetes_frame['BloodPressure']=diabetes_frame['BloodPressure'].fillna(diabetes_frame['BloodPressure'].mean())


# In[68]:


diabetes_frame['Outcome']=diabetes_frame['Outcome'].fillna(diabetes_frame['Outcome'].mode())


# In[69]:


diabetes_frame1=diabetes_frame.drop(columns =['SkinThickness','DiabetesPedigreeFunction']) 


# In[70]:


diabetes_frame1['BMI']=diabetes_frame1['BMI'].fillna(diabetes_frame1['BMI'].mean())


# In[71]:


diabetes_frame1['Age']=diabetes_frame1['Age'].fillna(diabetes_frame1['Age'].mean())


# In[72]:


diabetes_frame1['Age']=diabetes_frame1['Age'].fillna(diabetes_frame1['Age'].mean())


# In[73]:


diabetes_frame1['Glucose']=diabetes_frame1['Glucose'].fillna(diabetes_frame1['Glucose'].mean())


# In[74]:


diabetes_frame1['Pregnancies']=diabetes_frame1['Pregnancies'].fillna(diabetes_frame1['Pregnancies'].mode())


# In[78]:


Y = diabetes_frame1['Outcome']
Y.head(5)


# In[80]:


X = diabetes_frame1.drop('Outcome', 1)


# In[81]:


X.head()


# In[83]:


from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, train_size=0.8, test_size=0.2, random_state=0)
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)


# In[85]:


X_test


# In[86]:


from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression


# In[87]:


dt = DecisionTreeClassifier() 
lt=LogisticRegression()
xg = XGBClassifier()


# In[92]:


xg.fit(X_train, Y_train)


# In[93]:


print("XGBoost Score: ",xg.score(X_test, Y_test))


# In[95]:


classifier = AdaBoostClassifier(n_estimators=100, base_estimator=lt,learning_rate=0.5)


# In[96]:


classifier.fit(X_train,Y_train)


# In[100]:


y_pred = classifier.predict(X_test)
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(Y_test, y_pred)
print("Confusion matrix:\n%s" % cm)
accuracy=(sum(cm.diagonal())/cm.sum())*100
print("accuracy is :" ,accuracy)


# In[103]:


lt=LogisticRegression()
lt.fit(X_train,Y_train)


# In[104]:


y_pred = lt.predict(X_test)
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(Y_test, y_pred)
print("Confusion matrix:\n%s" % cm)
accuracy=(sum(cm.diagonal())/cm.sum())*100
print("accuracy is :" ,accuracy)


# In[105]:


dt=DecisionTreeClassifier() 
dt.fit(X_train,Y_train)


# In[ ]:





# In[106]:


y_pred = dt.predict(X_test)
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(Y_test, y_pred)
print("Confusion matrix:\n%s" % cm)
accuracy=(sum(cm.diagonal())/cm.sum())*100
print("accuracy is :" ,accuracy)


# In[107]:


rf=RandomForestClassifier()
rf.fit(X_train,Y_train)


# In[108]:


y_pred = rf.predict(X_test)
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(Y_test, y_pred)
print("Confusion matrix:\n%s" % cm)
accuracy=(sum(cm.diagonal())/cm.sum())*100
print("accuracy is :" ,accuracy)


# In[109]:


from sklearn.naive_bayes import GaussianNB
naive = GaussianNB()
naive.fit(X_train, Y_train)


# In[110]:


y_pred = naive.predict(X_test)
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(Y_test, y_pred)
print("Confusion matrix:\n%s" % cm)
accuracy=(sum(cm.diagonal())/cm.sum())*100
print("accuracy is :" ,accuracy)

